package controller;

/**
 * A class used to represent an AI player profile in which the moves to be executed are determined.
 * By a defined logic.
 */
public class AIPlayer implements Player {
  // To be implemented to have a getPlayerType() method and a method to execute a move
}
