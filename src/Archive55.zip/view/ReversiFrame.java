package view;

import javax.swing.JFrame;

public class ReversiFrame extends JFrame {
  private BoardPanel boardPanel;

  public ReversiFrame() {
    boardPanel = new BoardPanel(20);
    this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    this.add(boardPanel);
    this.pack();
  }
}

