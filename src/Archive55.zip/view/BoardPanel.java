package view;

import javax.swing.JPanel;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Color;

public class BoardPanel extends JPanel {
  private final Hexagon[] hexagons;
  private final int hexSize;
  private final double hexWidth;
  private final double hexHeight;
  private final double rowHeight;

  public BoardPanel(int hexSize) {
    this.hexSize = hexSize;
    this.hexagons = new Hexagon[7];
    this.setBackground(Color.WHITE);

    // Calculated properties of hexagons
    this.hexWidth = Math.sqrt(3) * hexSize;
    this.hexHeight = 2 * hexSize;
    this.rowHeight = 1.5 * hexSize;

    // Starting positions for the first hexagon
    double startX = 100 + (hexWidth / 2); // Center the first row with respect to the second
    double startY = 100;

    // Initialize the first row of hexagons
    for (int i = 0; i < 3; i++) {
      double x = startX + (hexWidth * i);
      hexagons[i] = new Hexagon(x, startY, hexSize);
    }

    // Initialize the second row of hexagons
    // Start half a hexagon width to the left of the first hexagon of the first row
    double secondRowStartX = startX - (hexWidth / 2);
    for (int i = 3; i < 7; i++) {
      double x = secondRowStartX + (hexWidth * (i - 3));
      double y = startY + rowHeight;
      hexagons[i] = new Hexagon(x, y, hexSize);
    }
  }

  @Override
  public Dimension getPreferredSize() {
    // Adjust width and height to accommodate the hexagons
    double width = 4 * (hexWidth * 3 / 4) + hexWidth / 2 + 200;
    double height = hexHeight + rowHeight + 100;
    return new Dimension((int) Math.ceil(width), (int) Math.ceil(height));
  }

  @Override
  protected void paintComponent(Graphics g) {
    super.paintComponent(g);
    Graphics2D g2d = (Graphics2D) g;

    // Draw all hexagons
    g2d.setColor(Color.BLACK);
    for (Hexagon hexagon : hexagons) {
      g2d.draw(hexagon);
    }
  }
}





