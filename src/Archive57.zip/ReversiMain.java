import view.ReversiFrame;

public final class ReversiMain {
  public static void main(String[] args) {
    ReversiFrame view = new ReversiFrame(6);
    view.setVisible(true);
  }
}
