package controller;

/**
 * A class used to represent a human player profile in which the user controllers inputs.
 * Manually.
 */
public class HumanPlayer implements Player{
  // To be implemented to have a getPlayerType() method and a method to execute a move
}
