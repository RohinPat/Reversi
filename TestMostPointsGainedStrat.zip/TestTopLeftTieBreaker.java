package cs3500.reversi.player;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

import cs3500.reversi.model.HexCoord;

/**
 * Testing the top left tie-breaker.
 */
public class TestTopLeftTieBreaker {

  TopLeftTieBreaker tieBreaker;

  @Before
  public void init() {
    this.tieBreaker = new TopLeftTieBreaker();
  }

  @Test
  public void testThrowsIfNoInputs() {
    Assert.assertThrows(NullPointerException.class, () -> tieBreaker.breakTie(null));
  }

  @Test
  public void testThrowsIfEmptyInputs() {
    Assert.assertThrows(IllegalArgumentException.class, () -> tieBreaker.breakTie(List.of()));
  }

  @Test
  public void testWorksWhenTwoCoordsInSameRow() {

    List<HexCoord> inputs = new ArrayList<>();
    inputs.add(new HexCoord(1,-2,1));
    inputs.add(new HexCoord(0,-2,2));

    Assert.assertEquals(new HexCoord(0,-2,2), tieBreaker.breakTie(inputs));
  }

  @Test
  public void testWorksWhenTwoCoordsInColDiffRow() {

    List<HexCoord> inputs = new ArrayList<>();
    inputs.add(new HexCoord(-1,0,1));
    inputs.add(new HexCoord(0,-2,2));

    Assert.assertEquals(new HexCoord(0,-2,2), tieBreaker.breakTie(inputs));
  }

  @Test
  public void testWorksWhenLotsCoords() {

    List<HexCoord> inputs = new ArrayList<>();
    inputs.add(new HexCoord(1,-2,1));
    inputs.add(new HexCoord(0,-2,2));
    inputs.add(new HexCoord(0,-4,4));
    inputs.add(new HexCoord(4,-2,-2));
    inputs.add(new HexCoord(1,2,-3));
    inputs.add(new HexCoord(-4,0,4));


    Assert.assertEquals(new HexCoord(0,-4,4), tieBreaker.breakTie(inputs));
  }
}
