package cs3500.reversi.player;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import cs3500.reversi.model.BasicReversi;
import cs3500.reversi.model.HexagonBoard;
import cs3500.reversi.model.PlayerOwnership;
import cs3500.reversi.model.ReversiMutableModel;

/**
 * Testing the strategy wrapper.
 */
public class TestStrategyWrapper {

  StrategyWrapper wrapper;
  ReversiMutableModel model;
  InFallableReversiStrategy strategy;

  @Before
  public void init() {
    this.model = new BasicReversi();
    this.strategy = new MostPointsGainedStrategy();
    this.wrapper = new StrategyWrapper(this.strategy);
  }

  @Test
  public void testNullStratThrows() {
    Assert.assertThrows(NullPointerException.class, () -> new StrategyWrapper(null));
  }

  @Test
  public void testNullInputsForExecute() {
    Assert.assertThrows(NullPointerException.class, () -> wrapper.executeStrategy(null, null));
  }

  @Test
  public void testReturnsListOfCoordsWithoutScore() {
    model.startGame(new HexagonBoard(3));
    String expected = "[1 -2 1, " +
            "-2 1 1, " +
            "-1 -1 2, " +
            "1 1 -2, " +
            "2 -1 -1, " +
            "-1 2 -1]";
    Assert.assertEquals(expected,
            wrapper.executeStrategy(model, PlayerOwnership.PLAYER_1).toString());
  }

  @Test
  public void testThrowsIfGameNotStarted() {
    Assert.assertThrows(IllegalStateException.class, () ->
            wrapper.executeStrategy(model, PlayerOwnership.PLAYER_1));
  }

  @Test
  public void testThrowsIfNotPlayerTurn() {
    model.startGame(new HexagonBoard(3));
    Assert.assertThrows(IllegalStateException.class, () ->
            wrapper.executeStrategy(model, PlayerOwnership.PLAYER_2));
  }
}
