package cs3500.reversi.player;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import cs3500.reversi.model.BasicReversi;
import cs3500.reversi.model.HexagonBoard;
import cs3500.reversi.model.PlayerOwnership;
import cs3500.reversi.model.ReversiMutableModel;

/**
 * Testing the most points gained strategy.
 */
public class TestMostPointsGainedStrat {

  MostPointsGainedStrategy strategy;
  StrategyWrapper wrapper;
  ReversiStrategyTieBreaker tieBreaker;
  ReversiMutableModel model;
  StringBuilder sb;

  @Before
  public void init() {
    this.sb = new StringBuilder();
    this.strategy = new MostPointsGainedStrategy();
    this.wrapper = new StrategyWrapper(strategy);
    this.tieBreaker = new TopLeftTieBreaker();
    model = new MockReversiModel(new BasicReversi(), this.sb);
  }

  @Test
  public void testStrategyOnNullModelOrPlayerThrows() {
    Assert.assertThrows(NullPointerException.class, () -> strategy.executeStrategyGivenMoves(null,
        PlayerOwnership.PLAYER_1));
    Assert.assertThrows(NullPointerException.class, () -> strategy.executeStrategyGivenMoves(model,
        null));
  }

  @Test
  public void testStratOnNonStartedModelThrows() {
    Assert.assertThrows(IllegalStateException.class, () ->
        strategy.executeStrategyGivenMoves(model, PlayerOwnership.PLAYER_1));
  }

  @Test
  public void testStratOnNonExistingPlayerThrows() {
    model.startGame(new HexagonBoard(3));
    Assert.assertThrows(IllegalArgumentException.class, () ->
        strategy.executeStrategyGivenMoves(model, PlayerOwnership.UNOCCUPIED));
  }

  @Test
  public void testStratOnPlayerWrongTurnThrows() {
    model.startGame(new HexagonBoard(3));
    Assert.assertThrows(IllegalStateException.class, () ->
        strategy.executeStrategyGivenMoves(model, PlayerOwnership.PLAYER_2));
  }

  @Test
  public void testDoesWhatModelSays() {
    model.startGame(new HexagonBoard(3));
    ReversiMutableModel mock = new MockModel21(model);
    String exp = "[Val 1: 2 -1 -1 Val 2: 100]";
    Assert.assertEquals(exp, strategy.executeStrategyGivenMoves(mock,
            PlayerOwnership.PLAYER_1).toString());
  }

  @Test
  public void testStrategyProperlyReturnsMoves() {
    model.startGame(new HexagonBoard(3));

    String expected = "[Val 1: 1 -2 1 Val 2: 2, " +
        "Val 1: -2 1 1 Val 2: 2, " +
        "Val 1: -1 -1 2 Val 2: 2, " +
        "Val 1: 1 1 -2 Val 2: 2, " +
        "Val 1: 2 -1 -1 Val 2: 2, " +
        "Val 1: -1 2 -1 Val 2: 2]";

    Assert.assertEquals(expected, strategy.executeStrategyGivenMoves(model,
        PlayerOwnership.PLAYER_1).toString());
  }


  @Test
  public void testStrategyProperlyProdsModel() {
    model.startGame(new HexagonBoard(3));
    strategy.executeStrategyGivenMoves(model, PlayerOwnership.PLAYER_1);
    String expected = "1 -2 1:" +
        " -2 1 1:" +
        " -1 -1 2:" +
        " 1 1 -2:" +
        " 2 -1 -1:" +
        " -1 2 -1: ";

    Assert.assertEquals(expected, this.sb.toString());
  }

  @Test
  public void testStrategyProperlyReturnsMovesForPlayer2After1MakesMove() {
    model.startGame(new HexagonBoard(3));
    model.placeDisk(tieBreaker.breakTie(wrapper.executeStrategy(model, PlayerOwnership.PLAYER_1)),
        PlayerOwnership.PLAYER_1);

    String expected = "[Val 1: -2 1 1 Val 2: 2, " +
        "Val 1: 2 -1 -1 Val 2: 2, " +
        "Val 1: -1 2 -1 Val 2: 2]";

    Assert.assertEquals(expected,
        strategy.executeStrategyGivenMoves(model, PlayerOwnership.PLAYER_2).toString());
  }

  @Test
  public void testStrategyProperlyProdsModelForPlayer2After1MakesMove() {
    model.startGame(new HexagonBoard(3));
    model.placeDisk(tieBreaker.breakTie(wrapper.executeStrategy(model, PlayerOwnership.PLAYER_1)),
        PlayerOwnership.PLAYER_1);
    strategy.executeStrategyGivenMoves(model, PlayerOwnership.PLAYER_2);
    String expected = "1 -2 1: -2 1 1: 2 -1 -1: -1 2 -1: ";
    String actual = sb.toString();
    Assert.assertTrue(actual.contains(expected));
  }

  @Test
  public void testStrategyReturnsEmptyListIfNoMovesPossible() {
    model.startGame(new HexagonBoard(2));
    Assert.assertTrue(model.isGameOver());
    Assert.assertTrue(
        strategy.executeStrategyGivenMoves(model, PlayerOwnership.PLAYER_1).isEmpty());
  }

  @Test
  public void testStrategyDoesntReturnMovesForOtherPlayer() {
    model.startGame(new HexagonBoard(3));
    ReversiMutableModel clone = model.cloneModel();
    clone.pass(PlayerOwnership.PLAYER_1);
    Assert.assertNotEquals(strategy.executeStrategyGivenMoves(model, PlayerOwnership.PLAYER_1),
        strategy.executeStrategyGivenMoves(clone, PlayerOwnership.PLAYER_2));
  }


}
