// Skeleton implementation of AIPlayer.java for future homework assignments:
/*
package Controller;

import Controller.Player;
import Model.Board;
import Model.Disc;

public class AIPlayer implements Player {
  private Disc discColor;

  @Override
  public Disc getDiscColor() {
    // TODO Auto-generated method stub
    throw new UnsupportedOperationException("Unimplemented method 'getDiscColor'");
  }

  @Override
  public void makeMove(Board board) {
    // TODO Auto-generated method stub
    throw new UnsupportedOperationException("Unimplemented method 'makeMove'");
  }
}
*/