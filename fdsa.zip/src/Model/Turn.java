package Model;

public enum Turn {
  BLACK, WHITE
}