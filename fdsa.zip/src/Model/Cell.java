package Model;

public class Cell {
  private Disc content;

  public Cell(Disc content) {
    this.content = content;
  }

  public Disc getContent() {
    return this.content;
  }


  public void setContent(Disc content) {
    this.content = content;
  }

}

