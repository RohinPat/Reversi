package Model;

public enum Disc {
  BLACK, WHITE, EMPTY
}
