package model;

public enum GameState {
  PRE, INPROGRESS, WHITEWIN, BLACKWIN
}
