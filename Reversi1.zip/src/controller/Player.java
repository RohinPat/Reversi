package controller;
// Skeleton implementation of Player.java for future homework assignments:
/*

import Model.Board;
import Model.Disc;

public interface Player {
  Disc getDiscColor();

  void makeMove(Board board);
}
*/