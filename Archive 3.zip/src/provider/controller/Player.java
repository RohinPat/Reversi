package provider.controller;

public class Player {
  //temporary stub
}
