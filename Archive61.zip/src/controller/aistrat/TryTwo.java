package controller.aistrat;

import model.Coordinate;
import model.Disc;
import model.Reversi;


/**
 * The  class implements the interface
 * and encapsulates two different strategies. It attempts to choose a move
 * using the first strategy and, if unsuccessful (returns null), it then
 * tries the second strategy.
 */
public class TryTwo implements ReversiStratagy {
  ReversiStratagy first, second;

  /**
   * Chooses a move in the Reversi game by first trying the primary strategy.
   * If the primary strategy returns null (indicating no move found),
   * it then tries the secondary strategy.
   *
   * @param model The Reversi game model representing the current state of the game.
   * @param turn  The object representing the current player's turn.
   * @return The chosen for the move, or null if no move is found.
   */
  public Coordinate chooseMove(Reversi model, Disc turn) {
    Coordinate ans = this.first.chooseMove(model, turn);
    if (ans == null) {
      ans = this.second.chooseMove(model, turn);
    }
    return ans;
  }
}
